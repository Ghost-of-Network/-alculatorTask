package parser.expressions;

public interface Expression {

    double expValue();
}
